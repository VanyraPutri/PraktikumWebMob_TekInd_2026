import { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, SafeAreaView, Platform, StyleSheet, TextInput, Alert } from 'react-native';

const DATA_GUDANG = [
      { id: '1', namaBarang: 'Baut M10', kategori: 'Hardware', stok: 20, lokasiRak: 'A-01' },
      { id: '2', namaBarang: 'Mur M09', kategori: 'Hardware', stok: 30, lokasiRak: 'A-02' },
      { id: '3', namaBarang: 'Oli Mesin 30L', kategori: 'Pelumas', stok: 12, lokasiRak: 'B-01' },
      { id: '4', namaBarang: 'Gear Box', kategori: 'Spare Part', stok: 4, lokasiRak: 'C-01' },
      { id: '5', namaBarang: 'Belt Conveyor', kategori: 'Spare Part', stok: 10, lokasiRak: 'C-02' },
      { id: '6', namaBarang: 'Sekrup 5mm', kategori: 'Hardware', stok: 15, lokasiRak: 'A-03' },
      { id: '7', namaBarang: 'Palu Besi', kategori: 'Tool', stok: 55, lokasiRak: 'D-01' },
      { id: '8', namaBarang: 'Obeng Set', kategori: 'Tool', stok: 35, lokasiRak: 'D-02' },
      { id: '9', namaBarang: 'Kunci Inggris', kategori: 'Tool', stok: 9, lokasiRak: 'D-03' },
      { id: '10', namaBarang: 'Pelumas Gemuk', kategori: 'Pelumas', stok: 5, lokasiRak: 'B-02' },
];

export default function HomeScreen({ navigation }) {
      const [cari, setCari] = useState('');
      const [barcode, setBarcode] = useState('');

      const dataFilter = DATA_GUDANG.filter(item =>
            item.namaBarang.toLowerCase().includes(cari.toLowerCase())
      );

      const handleBarcode = () => {
            const item = DATA_GUDANG.find(i => i.id === barcode);
            if (item) navigation.navigate('Detail', { item });
            else Alert.alert('Error', 'Barcode Tidak Ditemukan');
            setBarcode('');
      };

      return(
            <SafeAreaView style={styles.container}>
                  <TextInput
                  style={styles.search}
                  placeholder='Cari Barang...'
                  value={cari}
                  onChangeText={setCari}
                  />

                  <View style={styles.barcodeRow}>
                        <TextInput
                        style={styles.barcodeInput}
                        placeholder='ID Barcode (1-10)'
                        value={barcode}
                        onChangeText={setBarcode}
                        keyboardType='numeric'
                  />
                  <TouchableOpacity style={styles.barcodeBtn} onPress={handleBarcode}>
                        <Text style={styles.barcodeBtnText}>Scan</Text>
                  </TouchableOpacity>
                  </View>

                  <FlatList
                  data={dataFilter}
                  keyExtractor={item => item.id}
                  renderItem={({ item }) => (
                        <TouchableOpacity style={styles.card} onPress={() =>
                              navigation.navigate('Detail', { item })}>
                                    <Text style={styles.nama}>{item.namaBarang}</Text>
                                    <Text style={styles.detail}>Stok: {item.stok} | Rak: {item.lokasiRak}</Text>
                              </TouchableOpacity>
                  )}
                  ListEmptyComponent={<Text style={styles.kosong}>Tidak Ada Barang</Text>}
                  />
            </SafeAreaView>
      );
}

const styles = StyleSheet.create({
      container: { flex: 1, backgroundColor: '#f5f5f5', paddingTop: Platform.OS === 'android' ? 25 : 0},
      search: { backgroundColor: 'white', padding: 12, margin: 16, marginBottom: 8, borderRadius: 10, fontSize: 16},
      barcodeRow: { flexDirection: 'row', marginHorizontal: 16, marginBottom: 8, gap: 10},
      barcodeInput: { backgroundColor: 'white', padding: 12, borderRadius: 10, flex: 2, fontSize: 16},
      barcodeBtn: { backgroundColor: '#27ae60', padding: 12, borderRadius: 10, alignItems: 'center', justifyContent: 'center', flex: 1 },
      barcodeBtnText: { color: 'white', fontWeight: 'bold', fontSize: 16},
      card: { backgroundColor: 'white', padding: 16, borderRadius: 10, marginHorizontal: 16, marginBottom: 8, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 2, elevation: 1 },
      nama: { fontSize: 16, fontWeight: 'bold', color: '#333' },
      detail: { fontSize: 14, color: '#666', marginTop: 4 },
      kosong: { textAlign: 'center', marginTop: 20, color: '#999'},
});